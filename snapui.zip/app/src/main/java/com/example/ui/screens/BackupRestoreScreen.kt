package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.SettingsBackupRestore
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FireCashBottomBar
import com.example.ui.components.FireCashTopBar
import com.example.ui.theme.FireCashBackground
import com.example.ui.theme.FireCashOnPrimary
import com.example.ui.theme.FireCashOnSecondaryContainer
import com.example.ui.theme.FireCashOnSurface
import com.example.ui.theme.FireCashOnSurfaceVariant
import com.example.ui.theme.FireCashOutline
import com.example.ui.theme.FireCashOutlineVariant
import com.example.ui.theme.FireCashPrimary
import com.example.ui.theme.FireCashSecondary
import com.example.ui.theme.FireCashSecondaryContainer
import com.example.ui.theme.FireCashSurfaceContainer
import com.example.ui.theme.FireCashSurfaceContainerHigh
import com.example.ui.theme.FireCashSurfaceContainerLow
import com.example.ui.theme.FireCashSurfaceVariant
import com.example.ui.viewmodel.Screen

@Composable
fun BackupRestoreScreen(
    autoBackupEnabled: Boolean,
    lastSyncTime: String,
    onToggleAutoBackup: (Boolean) -> Unit,
    onManualBackup: () -> Unit,
    onRestore: () -> Unit,
    onBack: () -> Unit,
    onProfileClick: () -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(FireCashBackground)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            FireCashTopBar(
                title = "FireCash",
                showBackButton = true,
                onBackClick = onBack,
                onProfileClick = onProfileClick
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Card 1: Sync Status Hero Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(FireCashSurfaceContainerLow)
                        .border(1.dp, FireCashSurfaceContainerHigh, RoundedCornerShape(20.dp))
                        .padding(20.dp)
                ) {
                    // Background cloud icon watermark
                    Icon(
                        imageVector = Icons.Default.CloudDone,
                        contentDescription = null,
                        tint = FireCashPrimary.copy(alpha = 0.08f),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(120.dp)
                    )

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(FireCashSecondaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sync,
                                    contentDescription = null,
                                    tint = FireCashOnSecondaryContainer,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Text(
                                text = "Sync Status",
                                color = FireCashOnSurface,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Text(
                            text = "Up to date",
                            color = FireCashOnSurface,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(FireCashSecondary)
                            )
                            Text(
                                text = "Last sync: $lastSyncTime",
                                color = FireCashOnSurfaceVariant,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Card 2: Restore Data Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(FireCashSurfaceContainerLow)
                        .border(1.dp, FireCashSurfaceContainerHigh, RoundedCornerShape(16.dp))
                        .padding(18.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Restore,
                                    contentDescription = null,
                                    tint = FireCashPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = "Restore Data",
                                    color = FireCashOnSurface,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(FireCashSurfaceContainer)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "42.8 MB",
                                    color = FireCashOnSurfaceVariant,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Text(
                            text = "Recover your expenses, receipts, and settings from your latest Google Drive backup.",
                            color = FireCashOnSurfaceVariant,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Button(
                            onClick = onRestore,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FireCashPrimary,
                                contentColor = FireCashOnPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("restore_from_drive_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "Restore from Drive",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                // Card 3: Backup Settings Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(FireCashSurfaceContainerLow)
                        .border(1.dp, FireCashSurfaceContainerHigh, RoundedCornerShape(16.dp))
                        .padding(18.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SettingsBackupRestore,
                                contentDescription = null,
                                tint = FireCashPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = "Backup Settings",
                                color = FireCashOnSurface,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Auto-Backup Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Auto-Backup",
                                    color = FireCashOnSurface,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "Daily sync over Wi-Fi",
                                    color = FireCashOnSurfaceVariant,
                                    fontSize = 12.sp
                                )
                            }

                            Switch(
                                checked = autoBackupEnabled,
                                onCheckedChange = onToggleAutoBackup,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = FireCashOnPrimary,
                                    checkedTrackColor = FireCashPrimary,
                                    uncheckedThumbColor = FireCashOutline,
                                    uncheckedTrackColor = FireCashSurfaceVariant
                                ),
                                modifier = Modifier.testTag("auto_backup_switch")
                            )
                        }

                        HorizontalDivider(
                            color = FireCashSurfaceContainerHigh,
                            thickness = 1.dp
                        )

                        // Manual Backup Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Manual Backup",
                                    color = FireCashOnSurface,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "Force sync right now",
                                    color = FireCashOnSurfaceVariant,
                                    fontSize = 12.sp
                                )
                            }

                            OutlinedButton(
                                onClick = onManualBackup,
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, FireCashOutlineVariant),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = FireCashPrimary
                                ),
                                modifier = Modifier.testTag("manual_backup_button")
                            ) {
                                Text(
                                    text = "Backup Now",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                // Card 4: Info Encryption Note
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(FireCashSurfaceContainer)
                        .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = FireCashOutline,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Backups are encrypted using end-to-end AES-256 before being uploaded to your linked cloud storage. We cannot read your financial data.",
                            color = FireCashOnSurfaceVariant,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(70.dp))
            }
        }

        // Bottom Navigation Bar
        FireCashBottomBar(
            currentScreen = Screen.BackupRestore,
            onTabSelected = onNavigate,
            showBackupTab = true,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}
