package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FireCashTopBar
import com.example.ui.theme.FireCashBackground
import com.example.ui.theme.FireCashOnPrimaryContainer
import com.example.ui.theme.FireCashOnSurface
import com.example.ui.theme.FireCashOnSurfaceVariant
import com.example.ui.theme.FireCashOutline
import com.example.ui.theme.FireCashOutlineVariant
import com.example.ui.theme.FireCashPrimary
import com.example.ui.theme.FireCashPrimaryContainer
import com.example.ui.theme.FireCashSecondary
import com.example.ui.theme.FireCashSecondaryContainer
import com.example.ui.theme.FireCashSurfaceContainer
import com.example.ui.theme.FireCashSurfaceContainerHigh
import com.example.ui.theme.FireCashSurfaceContainerHighest

@Composable
fun ExportScreen(
    onExportCsv: (context: Context, fromDate: String, toDate: String) -> Unit,
    onExportPdf: (context: Context, fromDate: String, toDate: String) -> Unit,
    onBack: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var fromDate by remember { mutableStateOf("2023-10-01") }
    var toDate by remember { mutableStateOf("2023-10-31") }
    var selectedQuickRange by remember { mutableStateOf("This Month") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(FireCashBackground)
    ) {
        FireCashTopBar(
            title = "FireCash",
            showBackButton = true,
            onBackClick = onBack,
            onProfileClick = onProfileClick
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Header
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Export Data",
                    color = FireCashOnSurface,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Select a date range and format to generate your report.",
                    color = FireCashOnSurfaceVariant,
                    fontSize = 14.sp
                )
            }

            // Date Range Picker Card (Level 1 Elevation)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(FireCashSurfaceContainer)
                    .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // From Date
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "FROM",
                                color = FireCashPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            OutlinedTextField(
                                value = fromDate,
                                onValueChange = { fromDate = it },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.CalendarToday,
                                        contentDescription = null,
                                        tint = FireCashOnSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                textStyle = TextStyle(
                                    color = FireCashOnSurface,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = FireCashSurfaceContainerHigh,
                                    unfocusedContainerColor = FireCashSurfaceContainerHigh,
                                    focusedBorderColor = FireCashPrimary,
                                    unfocusedBorderColor = FireCashOutlineVariant
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("export_from_date")
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = FireCashOutline,
                            modifier = Modifier
                                .padding(top = 20.dp)
                                .size(20.dp)
                        )

                        // To Date
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "TO",
                                color = FireCashPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            OutlinedTextField(
                                value = toDate,
                                onValueChange = { toDate = it },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.CalendarToday,
                                        contentDescription = null,
                                        tint = FireCashOnSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                textStyle = TextStyle(
                                    color = FireCashOnSurface,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = FireCashSurfaceContainerHigh,
                                    unfocusedContainerColor = FireCashSurfaceContainerHigh,
                                    focusedBorderColor = FireCashPrimary,
                                    unfocusedBorderColor = FireCashOutlineVariant
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("export_to_date")
                            )
                        }
                    }

                    // Quick Selectors
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("This Month", "Last Month", "YTD").forEach { label ->
                            val isSelected = selectedQuickRange == label
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(
                                        if (isSelected) FireCashPrimaryContainer.copy(alpha = 0.25f)
                                        else FireCashSurfaceContainerHigh
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) FireCashPrimary.copy(alpha = 0.4f) else FireCashOutlineVariant.copy(alpha = 0.4f),
                                        shape = RoundedCornerShape(20.dp)
                                    )
                                    .clickable {
                                        selectedQuickRange = label
                                        when (label) {
                                            "This Month" -> {
                                                fromDate = "2023-10-01"
                                                toDate = "2023-10-31"
                                            }
                                            "Last Month" -> {
                                                fromDate = "2023-09-01"
                                                toDate = "2023-09-30"
                                            }
                                            "YTD" -> {
                                                fromDate = "2023-01-01"
                                                toDate = "2023-10-31"
                                            }
                                        }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) FireCashPrimary else FireCashOnSurfaceVariant,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // Export Cards Grid
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // Export CSV Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(FireCashSurfaceContainerHighest)
                        .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                        .clickable { onExportCsv(context, fromDate, toDate) }
                        .padding(24.dp)
                        .testTag("export_csv_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(FireCashSecondaryContainer.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TableView,
                                contentDescription = null,
                                tint = FireCashSecondary,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Text(
                            text = "Export as CSV",
                            color = FireCashOnSurface,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Text(
                            text = "Raw data for Excel or Google Sheets",
                            color = FireCashOnSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                }

                // Export PDF Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(FireCashPrimaryContainer)
                        .shadow(12.dp, spotColor = FireCashPrimaryContainer)
                        .clickable { onExportPdf(context, fromDate, toDate) }
                        .padding(24.dp)
                        .testTag("export_pdf_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(FireCashOnPrimaryContainer.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                tint = FireCashOnPrimaryContainer,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Text(
                            text = "Export as PDF",
                            color = FireCashOnPrimaryContainer,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "Formatted receipt summary",
                            color = FireCashOnPrimaryContainer.copy(alpha = 0.85f),
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // Watermark Graphic
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ReceiptLong,
                    contentDescription = null,
                    tint = FireCashPrimary.copy(alpha = 0.15f),
                    modifier = Modifier.size(100.dp)
                )
            }
        }
    }
}
