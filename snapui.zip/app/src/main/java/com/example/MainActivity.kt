package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.data.local.FireCashDatabase
import com.example.data.repository.ExpenseRepository
import com.example.data.repository.SettingsRepository
import com.example.ui.MainApp
import com.example.ui.theme.FireCashTheme
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = FireCashDatabase.getDatabase(applicationContext)
        val expenseRepository = ExpenseRepository(database.expenseDao(), database.keywordRuleDao())
        val settingsRepository = SettingsRepository(applicationContext)

        val factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return MainViewModel(expenseRepository, settingsRepository) as T
            }
        }

        viewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]

        setContent {
            FireCashTheme {
                MainApp(viewModel = viewModel)
            }
        }
    }
}

