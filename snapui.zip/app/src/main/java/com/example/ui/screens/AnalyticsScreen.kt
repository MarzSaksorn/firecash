package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.analytics.AnalyticsSummary
import com.example.ui.components.FireCashBottomBar
import com.example.ui.components.FireCashTopBar
import com.example.ui.theme.FireCashBackground
import com.example.ui.theme.FireCashError
import com.example.ui.theme.FireCashErrorContainer
import com.example.ui.theme.FireCashInverseOnSurface
import com.example.ui.theme.FireCashInverseSurface
import com.example.ui.theme.FireCashOnPrimaryContainer
import com.example.ui.theme.FireCashOnSurface
import com.example.ui.theme.FireCashOnSurfaceVariant
import com.example.ui.theme.FireCashOutlineVariant
import com.example.ui.theme.FireCashPrimary
import com.example.ui.theme.FireCashPrimaryContainer
import com.example.ui.theme.FireCashSecondary
import com.example.ui.theme.FireCashSecondaryContainer
import com.example.ui.theme.FireCashSurfaceContainer
import com.example.ui.theme.FireCashSurfaceContainerHigh
import com.example.ui.theme.FireCashSurfaceContainerHighest
import com.example.ui.theme.FireCashSurfaceContainerLow
import com.example.ui.theme.FireCashTertiary
import com.example.ui.theme.FireCashTertiaryContainer
import com.example.ui.viewmodel.Screen
import java.util.Locale

@Composable
fun AnalyticsScreen(
    summary: AnalyticsSummary,
    currencySymbol: String,
    onBack: () -> Unit,
    onProfileClick: () -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTimeFrame by remember { mutableStateOf("Month") }
    var selectedBarIndex by remember { mutableStateOf(3) }

    val monthlyData = listOf(
        Pair("JAN", 400),
        Pair("FEB", 600),
        Pair("MAR", 300),
        Pair("APR", 800),
        Pair("MAY", 500),
        Pair("JUN", 700)
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(FireCashBackground)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            FireCashTopBar(
                title = "FireCash",
                showBackButton = true,
                onBackClick = onBack,
                onProfileClick = onProfileClick
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header Total Spent Section
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Total Spent",
                        color = FireCashOnSurfaceVariant,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = summary.formattedTotal,
                            color = FireCashOnSurface,
                            fontSize = 34.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Default,
                            letterSpacing = (-0.5).sp,
                            modifier = Modifier.testTag("analytics_total_spent")
                        )

                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(FireCashErrorContainer.copy(alpha = 0.25f))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = null,
                                tint = FireCashError,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "+${summary.changePercentage}%",
                                color = FireCashError,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // Time Controls Segmented Buttons
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(FireCashSurfaceContainer)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf("Day", "Week", "Month").forEach { frame ->
                        val isSelected = selectedTimeFrame == frame
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) FireCashSurfaceContainerHighest else Color.Transparent)
                                .clickable { selectedTimeFrame = frame }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = frame,
                                color = if (isSelected) FireCashOnSurface else FireCashOnSurfaceVariant,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium
                            )
                        }
                    }
                }

                // Bento Card 1: Spending Overview Bar Chart
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(FireCashSurfaceContainerLow)
                        .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Spending Overview",
                                color = FireCashOnSurface,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            IconButton(onClick = {}, modifier = Modifier.size(24.dp)) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "Options",
                                    tint = FireCashOnSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Chart Layout with Y-Axis and Bars
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                        ) {
                            // Y-Axis Labels
                            Column(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .padding(end = 12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "${currencySymbol}1k", color = FireCashOnSurfaceVariant, fontSize = 10.sp)
                                Text(text = "${currencySymbol}500", color = FireCashOnSurfaceVariant, fontSize = 10.sp)
                                Text(text = "${currencySymbol}0", color = FireCashOnSurfaceVariant, fontSize = 10.sp)
                            }

                            // Bars Container
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom
                            ) {
                                monthlyData.forEachIndexed { index, (month, amount) ->
                                    val isSelected = selectedBarIndex == index
                                    val barHeightFraction by animateFloatAsState(
                                        targetValue = (amount / 1000f).coerceIn(0.1f, 1f),
                                        animationSpec = tween(600),
                                        label = "bar_height"
                                    )

                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Bottom,
                                        modifier = Modifier
                                            .fillMaxHeight()
                                            .clickable { selectedBarIndex = index }
                                    ) {
                                        if (isSelected) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(FireCashInverseSurface)
                                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = "$currencySymbol$amount",
                                                    color = FireCashInverseOnSurface,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                        }

                                        Box(
                                            modifier = Modifier
                                                .width(28.dp)
                                                .fillMaxHeight(barHeightFraction)
                                                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                                .background(
                                                    if (isSelected) FireCashPrimary
                                                    else FireCashPrimary.copy(alpha = 0.25f)
                                                )
                                                .then(
                                                    if (isSelected) Modifier.shadow(8.dp, spotColor = FireCashPrimary)
                                                    else Modifier
                                                )
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Text(
                                            text = month,
                                            color = if (isSelected) FireCashPrimary else FireCashOnSurfaceVariant,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // AI Insights Section
                if (summary.insights.isNotEmpty()) {
                    Text(
                        text = "AI Spending Insights",
                        color = FireCashOnSurface,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        summary.insights.forEach { insight ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(FireCashSurfaceContainerLow)
                                    .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
                                    .padding(14.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(FireCashPrimaryContainer.copy(alpha = 0.3f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = null,
                                            tint = FireCashPrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = insight.title,
                                            color = FireCashOnSurface,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = insight.description,
                                            color = FireCashOnSurfaceVariant,
                                            fontSize = 12.sp,
                                            lineHeight = 16.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Bento Card 2: Dynamic Category Spends
                if (summary.categorySpends.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(FireCashSurfaceContainerLow)
                            .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
                            .padding(18.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text(
                                text = "Top Categories",
                                color = FireCashOnSurface,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )

                            summary.categorySpends.forEachIndexed { idx, catSpend ->
                                val color = when (idx % 3) {
                                    0 -> FireCashSecondary
                                    1 -> FireCashTertiary
                                    else -> FireCashPrimary
                                }
                                val icon = when (catSpend.category.lowercase()) {
                                    "food & dining", "dining", "restaurant" -> Icons.Default.Restaurant
                                    "travel", "flight" -> Icons.Default.Flight
                                    "retail", "shopping" -> Icons.Default.ShoppingBag
                                    else -> Icons.Default.PieChart
                                }

                                DynamicCategoryProgressItem(
                                    icon = icon,
                                    name = catSpend.category,
                                    amount = "$currencySymbol${String.format(Locale.US, "%,.2f", catSpend.totalAmount)}",
                                    progress = catSpend.percentage,
                                    barColor = color
                                )
                            }
                        }
                    }
                }

                // Bento Highlights: Highest Single Expense & Frequent Merchant
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (summary.highestExpense != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(FireCashSurfaceContainerLow)
                                .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(4.dp)
                                            .height(44.dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(FireCashSecondary)
                                    )
                                    Column {
                                        Text(
                                            text = "HIGHEST SINGLE EXPENSE",
                                            color = FireCashOnSurfaceVariant,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            letterSpacing = 0.5.sp
                                        )
                                        Text(
                                            text = summary.highestExpense.merchant,
                                            color = FireCashOnSurface,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = summary.highestExpense.date,
                                            color = FireCashOnSurfaceVariant,
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                Text(
                                    text = "$currencySymbol${String.format(Locale.US, "%.2f", summary.highestExpense.amount)}",
                                    color = FireCashOnSurface,
                                    fontSize = 18.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Frequent Merchant
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(FireCashSurfaceContainerLow)
                            .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(4.dp)
                                        .height(44.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(FireCashTertiary)
                                )
                                Column {
                                    Text(
                                        text = "FREQUENT VENDOR",
                                        color = FireCashOnSurfaceVariant,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        letterSpacing = 0.5.sp
                                    )
                                    Text(
                                        text = summary.mostFrequentMerchant,
                                        color = FireCashOnSurface,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "${summary.frequentMerchantCount} transactions recorded",
                                        color = FireCashOnSurfaceVariant,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.Default.Repeat,
                                contentDescription = null,
                                tint = FireCashTertiary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Bottom Navigation Bar
        FireCashBottomBar(
            currentScreen = Screen.Analytics,
            onTabSelected = onNavigate,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun DynamicCategoryProgressItem(
    icon: ImageVector,
    name: String,
    amount: String,
    progress: Float,
    barColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(barColor.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = barColor,
                modifier = Modifier.size(20.dp)
            )
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = name,
                    color = FireCashOnSurface,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = amount,
                    color = FireCashOnSurfaceVariant,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Progress bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(FireCashSurfaceContainerHighest)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress.coerceIn(0.05f, 1f))
                        .fillMaxHeight()
                        .clip(CircleShape)
                        .background(barColor)
                )
            }
        }
    }
}
