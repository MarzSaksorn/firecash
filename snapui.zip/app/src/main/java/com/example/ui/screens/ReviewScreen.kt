package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.VerificationStatus
import com.example.ui.components.FireCashTopBar
import com.example.ui.theme.FireCashBackground
import com.example.ui.theme.FireCashError
import com.example.ui.theme.FireCashErrorContainer
import com.example.ui.theme.FireCashOnBackground
import com.example.ui.theme.FireCashOnPrimary
import com.example.ui.theme.FireCashOnSurface
import com.example.ui.theme.FireCashOnSurfaceVariant
import com.example.ui.theme.FireCashOutline
import com.example.ui.theme.FireCashOutlineVariant
import com.example.ui.theme.FireCashPrimary
import com.example.ui.theme.FireCashPrimaryContainer
import com.example.ui.theme.FireCashSecondary
import com.example.ui.theme.FireCashSecondaryContainer
import com.example.ui.theme.FireCashSurfaceContainer
import com.example.ui.theme.FireCashSurfaceContainerHigh
import com.example.ui.theme.FireCashSurfaceContainerHighest
import com.example.ui.viewmodel.ExtractedReceiptData

@Composable
fun ReviewScreen(
    data: ExtractedReceiptData,
    onConfirm: () -> Unit,
    onBack: () -> Unit,
    onProfileClick: () -> Unit,
    onUpdateData: (merchant: String, amount: String, date: String, category: String, tags: List<String>) -> Unit,
    modifier: Modifier = Modifier
) {
    var merchant by remember { mutableStateOf(data.merchant) }
    var amount by remember { mutableStateOf(data.amount) }
    var date by remember { mutableStateOf(data.date) }
    var category by remember { mutableStateOf(data.category) }
    var tags by remember { mutableStateOf(data.tags.toMutableList()) }

    var categoryDropdownExpanded by remember { mutableStateOf(false) }
    var showAddTagDialog by remember { mutableStateOf(false) }
    var newTagText by remember { mutableStateOf("") }
    var isManualEditActive by remember { mutableStateOf(false) }

    val categories = listOf("Travel", "Food & Dining", "Office Supplies", "Software", "Retail", "Transfer", "Other")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(FireCashBackground)
    ) {
        FireCashTopBar(
            title = "FireCash",
            showBackButton = true,
            onBackClick = onBack,
            onProfileClick = onProfileClick
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header Section
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Review Extracted Data",
                    color = FireCashOnBackground,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Confirm details and bank slip verification before saving.",
                    color = FireCashOnSurfaceVariant,
                    fontSize = 14.sp
                )
            }

            // EasySlip Verification Status Banner
            if (data.isDuplicate) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(FireCashErrorContainer.copy(alpha = 0.25f))
                        .border(1.dp, FireCashError.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = FireCashError,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "Duplicate Slip Detected",
                                color = FireCashError,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "CRC ${data.crc} was already logged previously.",
                                color = FireCashOnSurfaceVariant,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            } else if (data.isVerified) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(FireCashSecondaryContainer.copy(alpha = 0.15f))
                        .border(1.dp, FireCashSecondary.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = FireCashSecondary,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "EasySlip Verified ✓",
                                color = FireCashSecondary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Bank: ${data.sendingBankName} • Ref: ${data.transRef ?: "CRC " + data.crc}",
                                color = FireCashOnSurfaceVariant,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Form Area (Container Level 1)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(FireCashSurfaceContainer)
                    .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    .padding(20.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    // Merchant Field
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "MERCHANT / RECEIVER NAME",
                            color = FireCashOnSurfaceVariant,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        )
                        OutlinedTextField(
                            value = merchant,
                            onValueChange = {
                                merchant = it
                                onUpdateData(merchant, amount, date, category, tags)
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Store,
                                    contentDescription = null,
                                    tint = FireCashOnSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            textStyle = TextStyle(
                                color = FireCashOnSurface,
                                fontSize = 15.sp
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = FireCashSurfaceContainerHigh,
                                unfocusedContainerColor = FireCashSurfaceContainerHigh,
                                focusedBorderColor = FireCashPrimary,
                                unfocusedBorderColor = FireCashOutlineVariant
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("review_merchant_field")
                        )
                    }

                    // Total Amount Field
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "TOTAL AMOUNT",
                            color = FireCashOnSurfaceVariant,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        )
                        OutlinedTextField(
                            value = amount,
                            onValueChange = {
                                amount = it
                                onUpdateData(merchant, amount, date, category, tags)
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.AttachMoney,
                                    contentDescription = null,
                                    tint = FireCashOnSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            textStyle = TextStyle(
                                color = FireCashOnSurface,
                                fontSize = 16.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = FireCashSurfaceContainerHigh,
                                unfocusedContainerColor = FireCashSurfaceContainerHigh,
                                focusedBorderColor = FireCashPrimary,
                                unfocusedBorderColor = FireCashOutlineVariant
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("review_amount_field")
                        )
                    }

                    // Date Field
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "DATE",
                            color = FireCashOnSurfaceVariant,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        )
                        OutlinedTextField(
                            value = date,
                            onValueChange = {
                                date = it
                                onUpdateData(merchant, amount, date, category, tags)
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.CalendarToday,
                                    contentDescription = null,
                                    tint = FireCashOnSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            textStyle = TextStyle(
                                color = FireCashOnSurface,
                                fontSize = 15.sp,
                                fontFamily = FontFamily.Monospace
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = FireCashSurfaceContainerHigh,
                                unfocusedContainerColor = FireCashSurfaceContainerHigh,
                                focusedBorderColor = FireCashPrimary,
                                unfocusedBorderColor = FireCashOutlineVariant
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("review_date_field")
                        )
                    }

                    // Category Field (Dropdown)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "CATEGORY",
                            color = FireCashOnSurfaceVariant,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        )
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(FireCashSurfaceContainerHigh)
                                    .border(1.dp, FireCashOutlineVariant, RoundedCornerShape(10.dp))
                                    .clickable { categoryDropdownExpanded = true }
                                    .padding(horizontal = 14.dp, vertical = 14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Category,
                                        contentDescription = null,
                                        tint = FireCashOnSurfaceVariant,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = category,
                                        color = FireCashOnSurface,
                                        fontSize = 15.sp
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = FireCashOnSurfaceVariant
                                )
                            }

                            DropdownMenu(
                                expanded = categoryDropdownExpanded,
                                onDismissRequest = { categoryDropdownExpanded = false },
                                modifier = Modifier.background(FireCashSurfaceContainerHighest)
                            ) {
                                categories.forEach { cat ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = cat,
                                                color = FireCashOnSurface,
                                                fontSize = 14.sp
                                            )
                                        },
                                        onClick = {
                                            category = cat
                                            categoryDropdownExpanded = false
                                            onUpdateData(merchant, amount, date, category, tags)
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Tag Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        tags.forEach { tag ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(FireCashPrimaryContainer.copy(alpha = 0.2f))
                                    .border(1.dp, FireCashPrimary.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = tag,
                                    color = FireCashPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Add Tag Chip
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(FireCashSurfaceContainerHigh)
                                .border(1.dp, FireCashOutlineVariant, RoundedCornerShape(20.dp))
                                .clickable { showAddTagDialog = true }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = FireCashOnSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Tag",
                                color = FireCashOnSurfaceVariant,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // Original Receipt Preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(FireCashSurfaceContainerHighest)
                    .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = data.imageUrl,
                    contentDescription = "Original Receipt Image",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Dark overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f))
                )

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Receipt,
                        contentDescription = null,
                        tint = FireCashOnSurfaceVariant,
                        modifier = Modifier.size(32.dp)
                    )
                    Text(
                        text = "ORIGINAL RECEIPT",
                        color = FireCashOnSurfaceVariant,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                }
            }

            // Action Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                OutlinedButton(
                    onClick = { isManualEditActive = true },
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, FireCashOutline),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = FireCashOnSurface
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("edit_manually_button")
                ) {
                    Text(
                        text = "Edit Manually",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Button(
                    onClick = onConfirm,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FireCashPrimary,
                        contentColor = FireCashOnPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("confirm_details_button")
                ) {
                    Text(
                        text = "Confirm Details",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Add Tag Dialog
        if (showAddTagDialog) {
            AlertDialog(
                onDismissRequest = { showAddTagDialog = false },
                title = {
                    Text(
                        text = "Add Tag",
                        color = FireCashOnSurface,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                },
                text = {
                    OutlinedTextField(
                        value = newTagText,
                        onValueChange = { newTagText = it },
                        placeholder = { Text("e.g. Travel, Client Meal") },
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newTagText.isNotBlank()) {
                                tags.add(newTagText.trim())
                                onUpdateData(merchant, amount, date, category, tags)
                                newTagText = ""
                            }
                            showAddTagDialog = false
                        }
                    ) {
                        Text("Add")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddTagDialog = false }) {
                        Text("Cancel")
                    }
                },
                containerColor = FireCashSurfaceContainerHighest
            )
        }
    }
}
