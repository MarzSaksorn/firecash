package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Expense
import com.example.data.model.VerificationStatus
import com.example.ui.components.FireCashBottomBar
import com.example.ui.components.FireCashTopBar
import com.example.ui.theme.FireCashBackground
import com.example.ui.theme.FireCashError
import com.example.ui.theme.FireCashErrorContainer
import com.example.ui.theme.FireCashOnPrimaryContainer
import com.example.ui.theme.FireCashOnSurface
import com.example.ui.theme.FireCashOnSurfaceVariant
import com.example.ui.theme.FireCashOutline
import com.example.ui.theme.FireCashOutlineVariant
import com.example.ui.theme.FireCashPrimary
import com.example.ui.theme.FireCashPrimaryContainer
import com.example.ui.theme.FireCashSecondary
import com.example.ui.theme.FireCashSecondaryContainer
import com.example.ui.theme.FireCashSurfaceContainer
import com.example.ui.theme.FireCashSurfaceContainerHigh
import com.example.ui.theme.FireCashSurfaceContainerLow
import com.example.ui.theme.FireCashSurfaceVariant
import com.example.ui.viewmodel.Screen
import java.util.Locale

@Composable
fun ExpenseListScreen(
    expenses: List<Expense>,
    searchQuery: String,
    selectedCategory: String,
    currencySymbol: String,
    onSearchChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit,
    onAddExpense: () -> Unit,
    onDeleteExpense: (Expense) -> Unit,
    onProfileClick: () -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val categories = listOf("All", "Travel", "Food & Dining", "Office Supplies", "Software", "Retail", "Transfer")

    // Group expenses by dateGroup or date
    val groupedExpenses = remember(expenses) {
        expenses.groupBy { it.dateGroup.ifEmpty { "Recent" } }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(FireCashBackground)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            FireCashTopBar(
                title = "FireCash",
                showBackButton = false,
                onProfileClick = onProfileClick
            )

            // Search Bar & Filter Chips Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = {
                        Text(
                            text = "Search receipts, merchants, CRC...",
                            color = FireCashOnSurfaceVariant,
                            fontSize = 14.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = FireCashOnSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    textStyle = TextStyle(
                        color = FireCashOnSurface,
                        fontSize = 14.sp
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = FireCashSurfaceContainerHigh,
                        unfocusedContainerColor = FireCashSurfaceContainerHigh,
                        focusedBorderColor = FireCashPrimary,
                        unfocusedBorderColor = FireCashOutlineVariant.copy(alpha = 0.6f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("search_expenses_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Filter Chips Row
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(categories) { cat ->
                        val isSelected = selectedCategory == cat
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    if (isSelected) FireCashPrimary.copy(alpha = 0.15f)
                                    else FireCashSurfaceContainerHigh
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) FireCashPrimary.copy(alpha = 0.3f) else FireCashOutlineVariant.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(20.dp)
                                )
                                .clickable { onCategoryChange(cat) }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                                .testTag("filter_chip_$cat"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (cat == "All") {
                                Icon(
                                    imageVector = Icons.Default.Receipt,
                                    contentDescription = null,
                                    tint = if (isSelected) FireCashPrimary else FireCashOnSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = cat,
                                color = if (isSelected) FireCashPrimary else FireCashOnSurfaceVariant,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // Expense List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                groupedExpenses.forEach { (header, list) ->
                    item {
                        Text(
                            text = header,
                            color = FireCashOnSurfaceVariant,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)
                        )
                    }

                    items(list, key = { it.id }) { item ->
                        ExpenseItemCard(
                            expense = item,
                            currencySymbol = currencySymbol,
                            onDelete = { onDeleteExpense(item) }
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(88.dp))
                }
            }
        }

        // Floating Action Button
        FloatingActionButton(
            onClick = onAddExpense,
            containerColor = FireCashPrimaryContainer,
            contentColor = FireCashOnPrimaryContainer,
            elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 84.dp)
                .size(56.dp)
                .testTag("add_expense_fab")
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Add new receipt",
                modifier = Modifier.size(26.dp)
            )
        }

        // Bottom Navigation Bar
        FireCashBottomBar(
            currentScreen = Screen.Expenses,
            onTabSelected = onNavigate,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
fun ExpenseItemCard(
    expense: Expense,
    currencySymbol: String,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val categoryIcon = getCategoryIcon(expense.category)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(FireCashSurfaceContainerLow)
            .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
            .padding(12.dp)
            .testTag("expense_card_${expense.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Thumbnail Image or Category Icon
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(FireCashSurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (!expense.imageUrl.isNullOrEmpty()) {
                    AsyncImage(
                        model = expense.imageUrl,
                        contentDescription = expense.merchant,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = categoryIcon,
                        contentDescription = expense.category,
                        tint = FireCashOutline,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Merchant & Category Details
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = expense.merchant,
                        color = FireCashOnSurface,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                    if (expense.isDuplicate) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(FireCashErrorContainer.copy(alpha = 0.3f))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "DUP",
                                color = FireCashError,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else if (expense.isVerified) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Verified Slip",
                            tint = FireCashSecondary,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = categoryIcon,
                        contentDescription = null,
                        tint = FireCashOnSurfaceVariant,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = expense.category,
                        color = FireCashOnSurfaceVariant,
                        fontSize = 13.sp
                    )

                    if (!expense.crc.isNullOrBlank()) {
                        Text(
                            text = "• CRC: ${expense.crc}",
                            color = FireCashPrimary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Amount & Timestamp
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "$currencySymbol${String.format(Locale.US, "%.2f", expense.amount)}",
                    color = FireCashOnSurface,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = expense.time,
                    color = FireCashOnSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete expense",
                    tint = FireCashOutlineVariant,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

fun getCategoryIcon(category: String): ImageVector {
    return when {
        category.contains("Food", ignoreCase = true) || category.contains("Dining", ignoreCase = true) || category.contains("Meal", ignoreCase = true) -> Icons.Default.Restaurant
        category.contains("Travel", ignoreCase = true) || category.contains("Transport", ignoreCase = true) -> Icons.Default.LocalTaxi
        category.contains("Office", ignoreCase = true) || category.contains("Supplies", ignoreCase = true) -> Icons.Default.Devices
        category.contains("Software", ignoreCase = true) || category.contains("Cloud", ignoreCase = true) -> Icons.Default.Cloud
        category.contains("Retail", ignoreCase = true) || category.contains("Shop", ignoreCase = true) -> Icons.Default.ShoppingBag
        category.contains("Transfer", ignoreCase = true) -> Icons.Default.QrCode
        else -> Icons.Default.ReceiptLong
    }
}
