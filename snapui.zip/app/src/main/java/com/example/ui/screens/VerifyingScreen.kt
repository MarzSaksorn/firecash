package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FireCashBackground
import com.example.ui.theme.FireCashError
import com.example.ui.theme.FireCashErrorContainer
import com.example.ui.theme.FireCashOnError
import com.example.ui.theme.FireCashOnSurface
import com.example.ui.theme.FireCashOnSurfaceVariant
import com.example.ui.theme.FireCashOutlineVariant
import com.example.ui.theme.FireCashPrimary
import com.example.ui.theme.FireCashPrimaryContainer
import com.example.ui.theme.FireCashSecondary
import com.example.ui.theme.FireCashSecondaryContainer
import com.example.ui.theme.FireCashSurfaceContainer
import com.example.ui.theme.FireCashSurfaceContainerHigh
import com.example.ui.theme.FireCashSurfaceContainerHighest
import com.example.ui.viewmodel.VerificationState

@Composable
fun VerifyingScreen(
    state: VerificationState,
    statusMessage: String,
    onRetry: () -> Unit,
    onManualContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "spin_indicator")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(FireCashBackground)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Main Verifying Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(FireCashSurfaceContainer)
                    .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                    .padding(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Spinner / Status Icon
                    Box(
                        modifier = Modifier.size(96.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        when (state) {
                            VerificationState.VERIFIED -> {
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(CircleShape)
                                        .background(FireCashSecondaryContainer.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = FireCashSecondary,
                                        modifier = Modifier.size(48.dp)
                                    )
                                }
                            }
                            VerificationState.DUPLICATE_WARNING -> {
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(CircleShape)
                                        .background(FireCashErrorContainer.copy(alpha = 0.3f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = FireCashError,
                                        modifier = Modifier.size(44.dp)
                                    )
                                }
                            }
                            VerificationState.ERROR -> {
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(CircleShape)
                                        .background(FireCashErrorContainer.copy(alpha = 0.3f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Error,
                                        contentDescription = null,
                                        tint = FireCashError,
                                        modifier = Modifier.size(44.dp)
                                    )
                                }
                            }
                            else -> {
                                CircularProgressIndicator(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .rotate(rotationAngle),
                                    color = FireCashPrimary,
                                    strokeWidth = 4.dp,
                                    trackColor = FireCashPrimary.copy(alpha = 0.2f)
                                )
                                Icon(
                                    imageVector = Icons.Default.DocumentScanner,
                                    contentDescription = null,
                                    tint = FireCashPrimary,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }
                    }

                    Text(
                        text = when (state) {
                            VerificationState.VERIFIED -> "Verified Successfully"
                            VerificationState.DUPLICATE_WARNING -> "Duplicate Slip Detected"
                            VerificationState.ERROR -> "Verification Issue"
                            else -> "Verifying & Extracting"
                        },
                        color = when (state) {
                            VerificationState.VERIFIED -> FireCashSecondary
                            VerificationState.DUPLICATE_WARNING, VerificationState.ERROR -> FireCashError
                            else -> FireCashPrimary
                        },
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("verifying_title")
                    )

                    Text(
                        text = statusMessage,
                        color = FireCashOnSurfaceVariant,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            }

            // Step Progress Checklist
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(FireCashSurfaceContainerHigh)
                    .border(1.dp, FireCashOutlineVariant.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StepRow(
                    stepNum = "1",
                    title = "ML Kit Text OCR",
                    subtitle = "Extracts amount, date, & merchant name",
                    isComplete = state != VerificationState.OCR_READING && state != VerificationState.IDLE,
                    isActive = state == VerificationState.OCR_READING
                )
                StepRow(
                    stepNum = "2",
                    title = "Tag 91 & CRC Extraction",
                    subtitle = "Detects PromptPay / EMVCo checksum",
                    isComplete = state == VerificationState.EASYSLIP_VERIFYING || state == VerificationState.VERIFIED || state == VerificationState.DUPLICATE_WARNING,
                    isActive = state == VerificationState.BANK_CRC_CHECK
                )
                StepRow(
                    stepNum = "3",
                    title = "EasySlip Proxy Validation",
                    subtitle = "Validates bank payload & duplicate check",
                    isComplete = state == VerificationState.VERIFIED,
                    isActive = state == VerificationState.EASYSLIP_VERIFYING
                )
            }

            // Error or Override Actions
            if (state == VerificationState.ERROR || state == VerificationState.DUPLICATE_WARNING) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onRetry,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Retry")
                    }

                    Button(
                        onClick = onManualContinue,
                        colors = ButtonDefaults.buttonColors(containerColor = FireCashPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) {
                        Text("Review Data")
                    }
                }
            }
        }
    }
}

@Composable
private fun StepRow(
    stepNum: String,
    title: String,
    subtitle: String,
    isComplete: Boolean,
    isActive: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(
                    when {
                        isComplete -> FireCashSecondaryContainer.copy(alpha = 0.3f)
                        isActive -> FireCashPrimaryContainer.copy(alpha = 0.4f)
                        else -> FireCashSurfaceContainerHighest
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isComplete) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = FireCashSecondary,
                    modifier = Modifier.size(18.dp)
                )
            } else {
                Text(
                    text = stepNum,
                    color = if (isActive) FireCashPrimary else FireCashOnSurfaceVariant,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = if (isActive || isComplete) FireCashOnSurface else FireCashOnSurfaceVariant,
                fontSize = 13.sp,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium
            )
            Text(
                text = subtitle,
                color = FireCashOnSurfaceVariant,
                fontSize = 11.sp
            )
        }
    }
}
