package com.example.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.BackupRestoreScreen
import com.example.ui.screens.CaptureScreen
import com.example.ui.screens.ExpenseListScreen
import com.example.ui.screens.ExportScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.ReviewScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VerifyingScreen
import com.example.ui.theme.FireCashBackground
import com.example.ui.theme.FireCashOnSurface
import com.example.ui.theme.FireCashSurfaceContainerHighest
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@Composable
fun MainApp(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val currentScreen by viewModel.currentScreen.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val rules by viewModel.rules.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val totalSpent by viewModel.totalSpent.collectAsState()
    val verificationState by viewModel.verificationState.collectAsState()
    val verificationStatusMessage by viewModel.verificationStatusMessage.collectAsState()
    val extractedData by viewModel.extractedData.collectAsState()
    val analyticsSummary by viewModel.analyticsSummary.collectAsState()

    val currency by viewModel.settingsRepository.currency.collectAsState()
    val driveSync by viewModel.settingsRepository.googleDriveSync.collectAsState()
    val autoBackup by viewModel.settingsRepository.autoBackup.collectAsState()
    val lastSync by viewModel.settingsRepository.lastSyncTime.collectAsState()

    val easySlipEnabled by viewModel.settingsRepository.easySlipEnabled.collectAsState()
    val proxyEndpoint by viewModel.settingsRepository.proxyEndpoint.collectAsState()
    val apiKey by viewModel.settingsRepository.apiKey.collectAsState()
    val checkDuplicates by viewModel.settingsRepository.checkDuplicates.collectAsState()

    var showProfileMenu by remember { mutableStateOf(false) }

    val currencySymbol = viewModel.settingsRepository.getCurrencySymbol(currency)

    // Listen for toast messages
    LaunchedEffect(Unit) {
        viewModel.toastMessage.collectLatest { message ->
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            scope.launch {
                snackbarHostState.showSnackbar(message, duration = SnackbarDuration.Short)
            }
        }
    }

    // Handle back button
    BackHandler(enabled = currentScreen !is Screen.Expenses) {
        viewModel.goBack()
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = FireCashBackground,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    (fadeIn() + slideInHorizontally(initialOffsetX = { 40 }))
                        .togetherWith(fadeOut() + slideOutHorizontally(targetOffsetX = { -40 }))
                },
                label = "screen_transition"
            ) { screen ->
                when (screen) {
                    is Screen.Onboarding -> {
                        OnboardingScreen(
                            onGetStarted = { viewModel.navigateTo(Screen.Expenses) }
                        )
                    }

                    is Screen.Capture -> {
                        CaptureScreen(
                            onCapture = { sourceType, preset -> viewModel.startVerification(sourceType, preset) },
                            onClose = { viewModel.navigateTo(Screen.Expenses) },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }

                    is Screen.Verifying -> {
                        VerifyingScreen(
                            state = verificationState,
                            statusMessage = verificationStatusMessage,
                            onRetry = { viewModel.retryVerification() },
                            onManualContinue = { viewModel.navigateTo(Screen.Review) }
                        )
                    }

                    is Screen.Review -> {
                        ReviewScreen(
                            data = extractedData,
                            onConfirm = { viewModel.confirmReceipt() },
                            onBack = { viewModel.goBack() },
                            onProfileClick = { showProfileMenu = true },
                            onUpdateData = { m, a, d, c, t ->
                                viewModel.updateExtractedData(m, a, d, c, t)
                            }
                        )
                    }

                    is Screen.Expenses -> {
                        ExpenseListScreen(
                            expenses = expenses,
                            searchQuery = searchQuery,
                            selectedCategory = selectedCategory,
                            currencySymbol = currencySymbol,
                            onSearchChange = { viewModel.setSearchQuery(it) },
                            onCategoryChange = { viewModel.setSelectedCategory(it) },
                            onAddExpense = { viewModel.navigateTo(Screen.Capture) },
                            onDeleteExpense = { viewModel.deleteExpense(it) },
                            onProfileClick = { showProfileMenu = true },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }

                    is Screen.Analytics -> {
                        AnalyticsScreen(
                            summary = analyticsSummary,
                            currencySymbol = currencySymbol,
                            onBack = { viewModel.goBack() },
                            onProfileClick = { showProfileMenu = true },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }

                    is Screen.Export -> {
                        ExportScreen(
                            onExportCsv = { ctx, from, to -> viewModel.exportCsv(ctx, from, to) },
                            onExportPdf = { ctx, from, to -> viewModel.exportPdf(ctx, from, to) },
                            onBack = { viewModel.goBack() },
                            onProfileClick = { showProfileMenu = true }
                        )
                    }

                    is Screen.Settings -> {
                        SettingsScreen(
                            currentCurrency = currency,
                            rules = rules,
                            googleDriveSync = driveSync,
                            easySlipEnabled = easySlipEnabled,
                            proxyEndpoint = proxyEndpoint,
                            apiKey = apiKey,
                            checkDuplicates = checkDuplicates,
                            onCurrencyChange = { viewModel.settingsRepository.setCurrency(it) },
                            onToggleDriveSync = { viewModel.settingsRepository.setGoogleDriveSync(it) },
                            onToggleEasySlip = { viewModel.settingsRepository.setEasySlipEnabled(it) },
                            onUpdateProxy = { viewModel.settingsRepository.setProxyEndpoint(it) },
                            onUpdateApiKey = { viewModel.settingsRepository.setApiKey(it) },
                            onToggleCheckDuplicates = { viewModel.settingsRepository.setCheckDuplicates(it) },
                            onAddRule = { kw, cat -> viewModel.addRule(kw, cat) },
                            onRemoveRule = { viewModel.removeRule(it) },
                            onNavigateToBackup = { viewModel.navigateTo(Screen.BackupRestore) },
                            onBack = { viewModel.goBack() }
                        )
                    }

                    is Screen.BackupRestore -> {
                        BackupRestoreScreen(
                            autoBackupEnabled = autoBackup,
                            lastSyncTime = lastSync,
                            onToggleAutoBackup = { viewModel.settingsRepository.setAutoBackup(it) },
                            onManualBackup = { viewModel.triggerBackup() },
                            onRestore = { viewModel.restoreFromDrive() },
                            onBack = { viewModel.goBack() },
                            onProfileClick = { showProfileMenu = true },
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                }
            }

            // Quick Profile Navigation Menu
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 48.dp, end = 16.dp)
            ) {
                DropdownMenu(
                    expanded = showProfileMenu,
                    onDismissRequest = { showProfileMenu = false },
                    modifier = Modifier.background(FireCashSurfaceContainerHighest)
                ) {
                    DropdownMenuItem(
                        text = { Text("Settings & Rules", color = FireCashOnSurface) },
                        onClick = {
                            showProfileMenu = false
                            viewModel.navigateTo(Screen.Settings)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Export Data (CSV / PDF)", color = FireCashOnSurface) },
                        onClick = {
                            showProfileMenu = false
                            viewModel.navigateTo(Screen.Export)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Backup & Restore", color = FireCashOnSurface) },
                        onClick = {
                            showProfileMenu = false
                            viewModel.navigateTo(Screen.BackupRestore)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Onboarding Walkthrough", color = FireCashOnSurface) },
                        onClick = {
                            showProfileMenu = false
                            viewModel.navigateTo(Screen.Onboarding)
                        }
                    )
                }
            }
        }
    }
}
