package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.SourceType
import com.example.data.ocr.SampleSlipPreset
import com.example.ui.components.FireCashBottomBar
import com.example.ui.theme.FireCashBackground
import com.example.ui.theme.FireCashOnPrimaryContainer
import com.example.ui.theme.FireCashOnSurface
import com.example.ui.theme.FireCashOnSurfaceVariant
import com.example.ui.theme.FireCashOutlineVariant
import com.example.ui.theme.FireCashPrimary
import com.example.ui.theme.FireCashPrimaryContainer
import com.example.ui.theme.FireCashSecondaryContainer
import com.example.ui.theme.FireCashSurfaceContainer
import com.example.ui.theme.FireCashSurfaceContainerHigh
import com.example.ui.theme.FireCashSurfaceContainerHighest
import com.example.ui.viewmodel.Screen

@Composable
fun CaptureScreen(
    onCapture: (SourceType, SampleSlipPreset?) -> Unit,
    onClose: () -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    var flashEnabled by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "viewfinder_scan")
    val scanLineFraction by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scan_fraction"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(FireCashBackground)
    ) {
        // Camera Feed Background
        AsyncImage(
            model = "https://lh3.googleusercontent.com/aida-public/AB6AXuDl04aYatL5JCQEw7wqA5C_uNjCNasMUrWAQUaiek70F3sQkiKeAauasP6Zbu1wVSo1-D9YuZBO7JEmbNbv-nHY6khSbBFR8ws5G2urBXLNYI9GrZvMIF9lfQzXiDjP1eyU472DL_sqSL12SNMGIjv04hZ2fpbpQNoVWrXUULt5RzTBA3okLUdx11NWdDPXg2kWOaOdJeROORmXCLPMcLZL3OKwk4tgMDSX0mQvydNpvcQj0RmiTu01pg",
            contentDescription = "Camera Viewfinder Feed",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Dark Vignette Gradients
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .align(Alignment.TopCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Black.copy(alpha = 0.8f), Color.Transparent)
                    )
                )
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(290.dp)
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, FireCashBackground.copy(alpha = 0.95f), FireCashBackground)
                    )
                )
        )

        // Top Bar Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 40.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(FireCashSurfaceContainerHigh.copy(alpha = 0.7f))
                    .testTag("capture_close_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close camera",
                    tint = Color.White
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(
                    onClick = { flashEnabled = !flashEnabled },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(FireCashSurfaceContainerHigh.copy(alpha = 0.7f))
                        .testTag("capture_flash_button")
                ) {
                    Icon(
                        imageVector = if (flashEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = "Flash toggle",
                        tint = if (flashEnabled) FireCashSecondaryContainer else Color.White
                    )
                }

                IconButton(
                    onClick = { /* Toggle Crop / Auto-align */ },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(FireCashSurfaceContainerHigh.copy(alpha = 0.7f))
                        .testTag("capture_crop_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Crop,
                        contentDescription = "Crop align",
                        tint = Color.White
                    )
                }
            }
        }

        // Viewfinder Frame Overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp, vertical = 110.dp),
            contentAlignment = Alignment.Center
        ) {
            // Viewfinder Bounds
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
            ) {
                // Top-Left Corner
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .size(32.dp)
                        .border(
                            width = 4.dp,
                            color = FireCashPrimary,
                            shape = RoundedCornerShape(topStart = 16.dp)
                        )
                )
                // Top-Right Corner
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(32.dp)
                        .border(
                            width = 4.dp,
                            color = FireCashPrimary,
                            shape = RoundedCornerShape(topEnd = 16.dp)
                        )
                )
                // Bottom-Left Corner
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .size(32.dp)
                        .border(
                            width = 4.dp,
                            color = FireCashPrimary,
                            shape = RoundedCornerShape(bottomStart = 16.dp)
                        )
                )
                // Bottom-Right Corner
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(32.dp)
                        .border(
                            width = 4.dp,
                            color = FireCashPrimary,
                            shape = RoundedCornerShape(bottomEnd = 16.dp)
                        )
                )

                // Laser Scanning Line
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp)
                        .align(Alignment.TopCenter)
                        .padding(top = (scanLineFraction * 320).dp)
                        .background(FireCashSecondaryContainer)
                        .shadow(12.dp, spotColor = FireCashSecondaryContainer)
                )
            }

            // Align receipt badge
            Row(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.7f))
                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.QrCodeScanner,
                    contentDescription = null,
                    tint = FireCashPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Align slip or receipt in frame",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Bottom Controls + Navigation
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Quick Sample Preset Bar (for instant testing of Tag 91 CRC, EasySlip, and receipts)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SampleSlipPreset.values().forEach { preset ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(FireCashSurfaceContainerHighest.copy(alpha = 0.85f))
                            .border(1.dp, FireCashOutlineVariant, RoundedCornerShape(14.dp))
                            .clickable { onCapture(SourceType.CAMERA, preset) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Column {
                            Text(
                                text = preset.title,
                                color = FireCashOnSurface,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = preset.subtitle,
                                color = FireCashOnSurfaceVariant,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }

            // Shutter Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Gallery button
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onCapture(SourceType.GALLERY, SampleSlipPreset.UBER_RIDE) }
                        .testTag("capture_gallery_picker")
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(FireCashSurfaceContainer)
                            .border(1.dp, FireCashOutlineVariant, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = "Pick from gallery",
                            tint = FireCashOnSurfaceVariant,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Gallery",
                        color = FireCashOnSurfaceVariant,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Shutter Button
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .border(4.dp, FireCashPrimary, CircleShape)
                        .clickable { onCapture(SourceType.CAMERA, null) }
                        .testTag("shutter_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(62.dp)
                            .clip(CircleShape)
                            .background(FireCashPrimaryContainer)
                            .shadow(16.dp, spotColor = FireCashPrimaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoCamera,
                            contentDescription = "Capture receipt photo",
                            tint = FireCashOnPrimaryContainer,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }

                // Upload button (PDF / File)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onCapture(SourceType.PDF_UPLOAD, SampleSlipPreset.KBANK_TRANSFER) }
                        .testTag("capture_upload_pdf")
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(FireCashSurfaceContainer)
                            .border(1.dp, FireCashOutlineVariant, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = "Upload document or PDF",
                            tint = FireCashOnSurfaceVariant,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "PDF / File",
                        color = FireCashOnSurfaceVariant,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Bottom Navigation Bar
            FireCashBottomBar(
                currentScreen = Screen.Capture,
                onTabSelected = onNavigate
            )
        }
    }
}
